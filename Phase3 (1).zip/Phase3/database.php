<?php

 $dbhost = "localhost";
 $dbuser = "ushter_phase3sol";
 $dbpass = "phase3";
 $db = "ushter_phase3sol";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
 
  ?>

   



